#!/usr/bin/env python3
import ms
import numpy as np
from functools import reduce

class CS:
	def __init__(self, ss, ws, u, ps):
		self.ss = ss
		self.ws = list(map(lambda w: ms.ws[w], ws))
		self.ns = list(map(lambda w: ms.ns[w], ws))
		self.u = ms.us[u]
		self.ps = ps

	def __mps(self):
		s = ms.i.shape[0]
		if self.ps[1] in self.ns[1]:
			self.ps[1] = (self.ps[1] + 1) % s
			self.ps[2] = (self.ps[2] + 1) % s
		if self.ps[0] in self.ns[0]:
			self.ps[1] = (self.ps[1] + 1) % s
		self.ps[0] = (self.ps[0] + 1) % s
		return self.ps[:]

	def e(self, c):
		ps = self.__mps()
		ws = list(map(lambda wp: (ms.d**wp[1])*wp[0]*(ms.d.I**wp[1]), zip(self.ws, ps)))
		iws = list(map(lambda w: w.I, ws[::-1]))
		ws.insert(0, self.ss)
		ws.append(self.u)
		ws.extend(iws)
		ws.append(self.ss)

		return c * reduce((lambda r, w: r * w), ws)


def pos(c):
	from string import ascii_uppercase
	return ascii_uppercase.index(c)

def expand(c):
	return ms.i[pos(c)]

def pack(r):
	from string import ascii_uppercase
	return ascii_uppercase[np.where(np.all(ms.i==r,axis=1))[0][0]]

def st(s, d):
	from string import ascii_uppercase
	i = ms.i.copy()
	s = pos(s)
	d = pos(d)

	i[[s, d]] = i[[d, s]]
	return i

def sts(ss):
	return reduce(lambda x, y: x*y, list(map(lambda s: st(s[0], s[1]), ss.split(' ')))) if len(ss) else ms.i

def create_cs(key):
	lines = key.split('\n')

	ss = sts(lines[0])
	ws = list(map(lambda x: int(x, 10) - 1, lines[1].split(' ')))
	u = int(lines[2], 10) - 1
	ps = list(map(lambda x: pos(x), lines[3].split(' ')))

	return CS(ss, ws, u, ps)

def encrypt(pt, key):
	cs = create_cs(key)
	return ''.join(map(lambda c: pack(cs.e(expand(c))), pt))


if __name__ == "__main__":
	import argparse
	parser = argparse.ArgumentParser(description='Encrypt text')
	parser.add_argument('-i', '--input', metavar='plaintext_file', help='Input plaintext file', required=True)
	parser.add_argument('-k', '--key', metavar='key_file', help='Input key file', required=True)
	parser.add_argument('-o', '--output', metavar='ciphertext_file',help='Output ciphertext file', required=True)
	args = parser.parse_args()

	import re
	pt = re.sub(r'[^A-Z]', '', open(args.input, 'r').read().upper())
	key = open(args.key, 'r').read()

	ct = encrypt(pt, key)

	open(args.output, 'w').write(ct)



