#!/usr/bin/env python
import random
import gmpy
import sys
import os
from itertools import cycle
from functools import reduce

A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ '

def filter(s):
	return reduce(lambda x, y: x + (y if y in A else ""), s.upper())


def ri(l):
	return 2 ** l + random.randint(0, 2 ** l)

def rp(l):
	return gmpy.next_prime(ri(l))

def l(n):
	return len((bin(n)[2:]))

def pfs(n):
	ds = [ d for d in range(2,n//2+1) if n % d == 0 ]
	return [ d for d in ds if \
			 all( d % od != 0 for od in ds if od != d ) ]

def p_(l, r):
	while True:
		p = rp(l)
		if (p-1)%r == 0 and gmpy.gcd((p-1)//r, r) == 1:
			return p

def q_(p, l, r):
	while True:
		q = gmpy.next_prime(p+ri(l//4))
		if gmpy.gcd((q-1), r) == 1:
			return q

def y_(l, r, fi, n):
	while True:
		y = ri(l)
		if not gmpy.gcd(y, n) == 1:
			continue
		c = True
		for pi in pfs(r):
			if pow(y, fi//pi, n) == 1:
				c = False
				break
		if c == True:
			return y

def u_(n):
	while True:
		u = ri(l(n)) % n
		if gmpy.gcd(u, n) == 1:
			return u

def g(l, r):
	p = p_(l, r)
	q = q_(p, l, r)

	n=p*q

	fi=(p-1)*(q-1)
	y = y_(l, r, fi, n)
	x = pow(y, fi//r, n)

	return y, n, fi, x

def e(m, k, r):
	y, n = k
	u = u_(n)
	return (pow(y, m, n)*pow(u, r, n)) % n

def main():
	import argparse
	parser = argparse.ArgumentParser(description='Encrypt text')
	parser.add_argument('-i', '--input', metavar='plaintext_file', help='Input plaintext file', required=True)
	parser.add_argument('-k', '--key', metavar='key_file', help='Input key file', required=True)
	parser.add_argument('-o', '--output', metavar='ciphertext_file',help='Output ciphertext file', required=True)
	args = parser.parse_args()

	with open(args.input, 'r') as ipt:
		pt = filter(ipt.read())

	with open(args.key, 'r') as ik:
		k = filter(ik.read())	

	y, n, fi, x = g(128, len(A))

	ct = [e(A.index(c), (y, n), len(A)) for c in pt]
	ck = [e(A.index(c), (y, n), len(A)) for c in k]

	out = reduce(lambda x, y: str(x) + " " + str(y), [ (a * b) % n for a, b in zip(ct, cycle(ck))])

	with open(args.output, 'w') as o:
		o.write("{} {}\n".format(n, x))
		o.write(out)

if __name__ == "__main__":
	main()
